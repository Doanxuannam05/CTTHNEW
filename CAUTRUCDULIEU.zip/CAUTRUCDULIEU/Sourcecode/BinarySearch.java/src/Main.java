import searchAlgorithm.BinarySearch;
import searchAlgorithm.LinearSearch;
import sortAlgorithm.*;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);  
        //
        System.out.println("nhap so luong phan tu cua mang: ");
        int arrayLength = scanner.nextInt();

        //
        int[] arrayInput = new int[arrayLength];

        //
        System.out.println("nhap cac phan tu cua mang: ");
        for (int i = 0; i < arrayLength; i++){
            System.out.print("phan tu thu " + i + ":");
            arrayInput[i] = scanner.nextInt();
        }
        //
        System.out.println("nhap gia tri can tim: ");
        int key = scanner.nextInt();
        callMeForLinearSearch(arrayInput, key);
        scanner.close();
    }
    //
    //
static void callMeForBinarySearch(int[] arrayInput, int key){
    System.out.println(BinarySearch.binarySearch(arrayInput, key));
}
//
static void callMeForLinearSearch(int[] arrayInput, int key){
    LinearSearch linearsearchInstance = new LinearSearch();
    System.out.println("vi tri cua phan tu can tim la: " + linearsearchInstance);
}
//
static void callMeForSelectionSort(int[] arrayInput){
    SelectionSort selectionSortInstance = new SelectionSort();
    System.out.println("mang truoc khi sap sep lai: ");
    SelectionSort.selectionSort(arrayInput);
    printArray(arrayInput);
}

static void callMeForInsertionSort(int[]arrayInput){    
    InsertionSort insertionSortInstance = new InsertionSort();
    printArray(arrayInput);
    insertionSortInstance.insertionSort(arrayInput);
    System.out.println("mang sau khi sap xep tu be den lon:");
    printArray(arrayInput);

    //
    insertionSortInstance.insertionSort(arrayInput);
    System.out.println("mang sau khi sap xep tu lon den be: ");
    printArray(arrayInput);
}
private static void printArray(int[] arrayInput) {
    // TODO Auto-generated method stub
    throw new UnsupportedOperationException("Unimplemented method 'printArray'");
}

}
